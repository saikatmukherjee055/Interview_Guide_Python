print("legacy")
